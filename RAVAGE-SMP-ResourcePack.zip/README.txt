==========================================================================
 RAVAGE SMP Resource Pack        "믿지 마라. 약탈하라. 살아남아라."
==========================================================================
 Minecraft Java Edition 1.21.4  |  pack_format = 46
 (pack_format 46 = Java 1.21.4, 공식 위키 Pack format 표로 확인함)
 기본 해상도 16x (GUI 일부만 큰 이미지) / 저사양 PC · 모바일 Bedrock 대응


1. 설치 방법 (개인 테스트)
--------------------------------------------------------------------------
 1) RAVAGE-SMP-ResourcePack.zip 을 .minecraft/resourcepacks/ 에 넣는다.
    (또는 폴더 RAVAGE-SMP-ResourcePack 를 그대로 넣어도 된다.)
 2) 게임 > 옵션 > 리소스 팩 에서 "RAVAGE SMP" 를 활성화한다.
 3) zip 안쪽 최상위에 pack.mcmeta 가 바로 보여야 한다. (폴더가 한 겹 더 있으면 안 됨)


2. 서버에 적용 (자동 다운로드)
--------------------------------------------------------------------------
 1) zip 을 웹 호스팅(GitHub Release, CDN 등)에 올리고 "직접 다운로드 링크"를 얻는다.
 2) server.properties:
      resource-pack=https://example.com/RAVAGE-SMP-ResourcePack.zip
      resource-pack-sha1=<zip 의 SHA-1>          (build.py 실행 시 출력됨)
      require-resource-pack=true
      resource-pack-prompt={"text":"RAVAGE SMP 리소스팩을 적용해야 접속할 수 있습니다."}
 3) 팩을 수정할 때마다 sha1 을 갱신해야 클라이언트가 새로 받는다.


3. 지원 범위
--------------------------------------------------------------------------
 Minecraft 1.21.4        : 지원 (다른 버전은 pack_format 이 달라 경고가 뜨거나 깨질 수 있음)
 Java Edition            : 전체 기능 지원
 Bedrock Edition (Geyser): 부분 지원 - 아래 6번 참고


4. 필요한 플러그인 (서버 측)
--------------------------------------------------------------------------
 리소스팩 자체는 플러그인 없이 "바닐라 아이템/블록/GUI/사운드/폰트"를 바꿉니다.
 아래 기능은 서버 플러그인이 아이템/텍스트를 내려줘야 보입니다.
   - 커스텀 아이템 지급 : 아무 아이템 플러그인 (/give, Paper API, Skript, 자체 플러그인)
   - 세력/약탈/현상금/시즌 로직 : RAVAGE 자체 플러그인 (또는 Factions 계열 + 스크립트)
   - GUI 제목 배경/HUD : 플러그인이 Adventure Component 로 폰트(font) 를 지정해 전송
   - 사운드 : /playsound 또는 Player#playSound 로 재생
   - 크로스플레이 : Geyser + Floodgate (+ Geyser 커스텀 아이템 매핑, 6번)


5. 커스텀 아이템 사용법 (1.21.4)
--------------------------------------------------------------------------
 두 가지 방법 중 편한 것을 쓰면 된다.

 (A) item_model  (베이스 아이템에 종속되지 않음, 권장)
     /give @p paper[item_model="minecraft:bounty_contract"]
 (B) custom_model_data (문자열)  - Geyser 매핑/기존 플러그인과 호환이 좋음
     /give @p paper[custom_model_data={strings:["bounty_contract"]}]

 아이템 ID (파일명 = ID)
   화폐      ravage_coin(동전) ravage_silver_coin(은화) ravage_gold_coin(금화) ravage_gem(보석)
   현상금    bounty_contract(현상금 계약서)
   세력      war_flag(전쟁 깃발) faction_badge(세력 문장) faction_flag(세력 깃발, 색 변경 가능)
             alliance_pact(동맹 증서) hostile_decree(적대 선언서)
   약탈      raid_key(약탈자의 열쇠) vault_key(금고 열쇠)
             raid_pickaxe(부서진 곡괭이, 베이스 stone_pickaxe)
             raid_axe(낡은 도끼, 베이스 stone_axe)
             raider_knife(약탈자의 칼, 베이스 stone_sword)
   보물상자  common_chest / rare_chest / legendary_chest
   기타      supply_crate (3D 블록 모양 아이템)

 * (B) 방식의 베이스 아이템: 대부분 paper, 도구 3종만 stone_pickaxe/stone_axe/stone_sword.
 * (A) 방식은 items/<id>.json 을 사용하므로 어떤 베이스 아이템에도 붙일 수 있음.
   예) /give @p iron_sword[item_model="minecraft:raider_knife"]

 세력 깃발 색상 변경 (faction_flag, 천 부분이 색상에 따라 물듦)
   /give @p paper[custom_model_data={strings:["faction_flag"],colors:[16711680]}]
   colors[0] = 10진 RGB (빨강 16711680 / 파랑 3368703 / 초록 4562762 ...)
 아이템 설명(lore) 예:
   /give @p paper[item_model="minecraft:bounty_contract",
      lore=['{"text":"현상금 대상의 처치 보상을 확인할 수 있습니다.","color":"gray","italic":false}']]


6. Bedrock (Geyser + Floodgate) 참고
--------------------------------------------------------------------------
 - Bedrock 은 Java 리소스팩을 그대로 못 쓴다. Geyser 가 서버에서 Java 팩을 받아
   Bedrock 팩으로 변환해 보내거나(Geyser 의 packs 폴더), "Geyser Pack Converter" /
   "Rainbow" 로 변환해서 넣어야 한다.
 - Java 전용(변환 불가/부분 지원) 기능과 대체 방안
     * 커스텀 폰트(ravage / ravage_hud) : Bedrock 미지원 -> 아이콘은 일반 유니코드
       기호로 대체:  ⚔ ☠ $ ★ ⚑ 🔥 ...  (Floodgate 플레이어에겐 font 지정 없이 전송)
     * GUI 제목 배경 글리프(menu_*) : Bedrock 은 표시 안 됨 -> 기본 상자 GUI + 아이템 로어로 정보 표시
     * 색상이 바뀌는 faction_flag(tint) : Bedrock 에서는 단색으로 표시 (색은 이름/로어로 표기 권장)
     * 파티클 텍스처 교체 : Bedrock 은 자체 파티클 사용 -> 사운드/타이틀로 대체
     * 갑옷 착용 모델/체스트 엔티티 텍스처 : 변환기 결과에 따라 다름
 - 아이템은 Geyser custom item mappings (custom_model_data 문자열 기준, 방법 B)로 연결한다.
   아이콘/로고/아이템 텍스처는 16x16 픽셀 아트라 변환 후에도 식별성이 유지되도록 만들었다.


7. 폰트 / GUI 글리프 사용법 (Java)
--------------------------------------------------------------------------
 Adventure/JSON 텍스트에 "font" 를 지정한다.

 (a) 제목 전용 폰트  font = "minecraft:ravage"
     - 영문/숫자는 굵은 픽셀 폰트, 한글은 기본 폰트(unifont 포함)로 자동 대체되어 깨지지 않는다.
     /title @a title {"text":"RAVAGE SMP 시즌 1","font":"minecraft:ravage","color":"red"}

 (b) HUD 폰트  font = "minecraft:ravage_hud"   (아이콘/플레이트/로고/메뉴 배경 글리프)
     아이콘 글리프 (8x8, 채팅/액션바/보스바/스코어보드 어디서나)
       \uE000 ⚔전쟁   \uE001 ☠위험   \uE002 돈     \uE003 현상금   \uE004 세력
       \uE005 약탈    \uE006 방어    \uE007 세력장 \uE008 동맹     \uE009 적대
       \uE00A 순위    \uE00B 보상    \uE00C 시즌   \uE00D 체크(전투종료)
       \uE00E 자물쇠  \uE00F 열쇠
     HUD 플레이트 (액션바용 배경 띠, 글자는 붉은/노란색 등으로 위에 겹쳐 그림)
       \uE100 전투 중(빨강)   \uE101 전투 종료(초록)   \uE102 약탈 가능(주황)
       \uE103 약탈 성공(금)   \uE104 약탈 실패(회색)   \uE105 현상금(금/검정)
     로고 글리프  \uE200  (높이 16px)
     메뉴 배경 오버레이  \uE300 세력  \uE301 약탈  \uE302 현상금  \uE303 시즌

     공백(space) 글리프 (글자 위치 조정용)
       음수: U+F801(-1) F802(-2) F804(-4) F808(-8) F810(-16) F820(-32) F840(-64) F880(-128) F900(-256) FA00(-512)
       양수: U+FB01(+1) FB02(+2) FB04(+4) FB08(+8) FB10(+16) FB20(+32) FB40(+64) FB80(+128) FC00(+256) FD00(+512)
     ※ 정확한 코드포인트는 assets/minecraft/font/ravage_hud.json 에서 확인 가능.

 예) 전투 표시 (액션바):
     {"text":"\uE100 ","font":"minecraft:ravage_hud"}
     {"text":"전투 중 14초","color":"white"}
   플레이트 위에 글자를 얹으려면 플레이트 글리프 뒤에 음수 공백으로 되돌아간 뒤 글자를 쓴다.

 예) 메뉴 배경 (54칸 상자 GUI 제목):
     구성:  \uF808 (-8, GUI 왼쪽 끝으로) + \uE300 (배경, 폭 176) + 되돌리기 공백 + 제목 글자
     - 배경 글리프의 폭은 176px 이므로 뒤에 -176 을 만들어 준다:
       (-128) + (-32) + (-16) = -176  ->  \uF880 \uF820 \uF810
     - 따라서 제목 문자열 = "\uF808\uE300\uF880\uF820\uF810" + "세력 정보"
       (font = minecraft:ravage_hud, 제목 글자는 기본 폰트 하위 참조로 한글이 정상 표시됨)


8. 사운드 이벤트 (전부 /playsound minecraft:<이벤트> 로 재생)
--------------------------------------------------------------------------
   ravage.ui.open / ravage.ui.click / ravage.ui.close
   ravage.combat.start / ravage.combat.end / ravage.combat.kill / ravage.combat.bounty_kill
   ravage.raid.start / ravage.raid.vault_open / ravage.raid.reward_rare
   ravage.raid.reward_legendary / ravage.raid.success / ravage.raid.fail
   ravage.season.start / ravage.season.end / ravage.season.reward
 사운드는 tools/audio.py 로 합성한 짧은 mono OGG (총 용량 매우 작음).
   /playsound minecraft:ravage.raid.success master @p


9. 파티클 (바닐라 파티클 텍스처 교체 - 새 파티클 타입은 만들 수 없음)
--------------------------------------------------------------------------
   minecraft:wax_on            -> 현상금 처치 (금빛 반짝임)
   minecraft:wax_off           -> 전설 아이템 획득 (보라 반짝임)
   minecraft:electric_spark    -> 약탈 성공 (붉은 불꽃)
   minecraft:totem_of_undying  -> 시즌 보상 (금/초록)
   minecraft:angry_villager    -> 세력 승리 / 적대 (붉은 교차 검)
   예) /particle minecraft:wax_on ~ ~1 ~ 0.3 0.5 0.3 0 12
 개수를 12~20 이하로 유지하면 성능 영향이 거의 없다. 이 파티클들은 바닐라에서 드물게
 쓰이므로 다른 곳에 미치는 영향은 작다. (바닐라가 색을 곱해 색조가 달라질 수 있음)


10. 포함된 내용
--------------------------------------------------------------------------
 - 무기: 철/금/다이아/네더라이트 검·도끼 (짧고 굵은 실루엣, 1인칭에서 화면을 덜 가림)
         활(당김 3단계) / 석궁(대기·당김·장전·폭죽)
 - 방어구: 철(생존자) / 금(귀족 약탈자) / 다이아(전쟁 장비) / 네더라이트(최종 전쟁 장비)
           - 인벤토리 아이콘 + 착용 모델(entity/equipment) 모두 교체
 - 블록: 돌, 조약돌(이끼), 석재 벽돌(금감/이끼), 벽돌, 철·금 블록, 네더랙, 네더 벽돌,
         붉은 네더 벽돌, 블랙스톤, 통, 상자(일반/함정/엔더 - 엔티티 텍스처)
 - GUI: 54칸 상자 GUI(generic_54) 다크 메탈 스타일 - 세력/약탈/현상금/시즌 메뉴 공통 바탕
        핫바/선택 칸, 아이콘 16종, HUD 플레이트 6종, 메뉴 오버레이 4종, 로고
 - 폰트: ravage(제목), ravage_hud(아이콘/플레이트)
 - 사운드 16종, 파티클 5종


11. 리소스팩 수정/재생성 방법
--------------------------------------------------------------------------
 모든 그래픽/사운드는 tools/ 의 파이썬 스크립트로 생성된다. (Python 3 + Pillow + numpy + ffmpeg)
     pip install pillow numpy
     python tools/build.py
   -> RAVAGE-SMP-ResourcePack/ 폴더와 RAVAGE-SMP-ResourcePack.zip 이 다시 만들어진다.
 - 색/모양 수정 : tools/art_items.py (아이템/무기/방어구 아이콘), art_world.py (블록/착용 방어구/상자),
                  art_gui.py (GUI/폰트/로고/아이콘), audio.py (사운드)
 - 새 커스텀 아이템 : build.py 의 add('이름', 이미지, '베이스아이템') 한 줄 추가
 - 또는 PNG 를 직접 덮어써도 된다 (파일명은 영어 소문자 + 언더스코어 유지, 16x16 권장).
 - 이 팩의 모든 텍스처는 새로 그린 것이며 Mojang 원본 에셋을 포함하지 않는다.

 알려진 한계
 - 상자(chest) 엔티티 텍스처는 바닐라 UV 배치를 기준으로 그렸으며, 게임에서 확인 후 미세 조정 권장.
 - 착용 방어구 텍스처도 표준 64x32 UV 기준이며 게임 내 확인 후 조정 권장.
 - 플러그인/서버 로직(세력, 약탈, 현상금, 시즌)은 이 리소스팩에 포함되지 않는다.
==========================================================================
